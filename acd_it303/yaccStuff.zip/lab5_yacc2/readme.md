###Assignments on YACC

1. Implement scientific calculator using lex and yacc.  
2. Write a parser to check the syntax for sql query select  
3. Program to recognize and evaluate valid arithmetic expression that uses operators +-\*/  
4. Program to recognise the nested IF control statements and display the number of levels of nesting.  
5. Parser for switch case Statements  
